# Elephant Dental Ltd

Production candidate for the Elephant Dental clinic management system.

## Authentication
- User-facing workflow remains: Role + Username + PIN.
- Existing 4-digit-or-longer PINs are supported.
- Firebase Authentication receives a derived internal password; the clinic PIN is not stored in Firestore.
- Existing legacy staff accounts can be migrated on first successful login while temporary open development rules are still active.

## Deployment order
1. Enable Firebase Authentication -> Email/Password.
2. Run/test the app while temporary development rules are active.
3. Log in each existing staff account once to migrate it.
4. Verify Administrator, Receptionist and Dentist access.
5. Deploy `firestore.rules` only after migration and testing.
6. Do not run factory reset until the production workflow has been verified.
